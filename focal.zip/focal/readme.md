cd arceya/focal

# build flytos image
docker build -t arceya/dev_noetic:base .

# run a container
docker-compose up -d

# to enable display
xhost local:root
